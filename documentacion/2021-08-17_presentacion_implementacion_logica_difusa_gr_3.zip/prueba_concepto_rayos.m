% prueba de concepto contador de rayos
% Daniel Rodriguez - 2021
% Cibernetica 3

% Ejemplo adaptado de tutorial de matlab

%% Paso 1: carga imagen
I = imread('img/rayos_2.jpg');
imshow(I);

%% Paso 2: Cambio a escala de grises y reducción de elementos en la imagen
g_img = rgb2gray(I);
imshow(g_img);
lv_gray=0.8;
i1=im2bw(g_img,lv_gray);
imshow(i1);

%% Paso 3: Rellenar agujeros
Ifilled = imfill(i1,'holes');
figure, imshow(Ifilled);

%% Paso 4: Segunda rellenada de agujeros
se = strel('disk', 1);
Iopenned = imopen(Ifilled,se);
% figure,imshowpair(Iopenned, I);
imshow(Iopenned);

%% Paso 5: Extraer datos estadisticos imagen
Iregion = regionprops(Iopenned, 'centroid');
[labeled,numObjects] = bwlabel(Iopenned,4);
stats = regionprops(labeled,'Eccentricity','Area','BoundingBox');
areas = [stats.Area];
eccentricities = [stats.Eccentricity];


%% Paso 6: Usar estadisticas para determinar los bordes de los rayos
idxOfSkittles = find(eccentricities);
statsDefects = stats(idxOfSkittles);

figure, imshow(I);
hold on;
for idx = 1 : length(idxOfSkittles)
        h = rectangle('Position',statsDefects(idx).BoundingBox,'LineWidth',2);
        set(h,'EdgeColor',[.75 0 0]);
        hold on;
end
if idx > 10
title(['There are ', num2str(numObjects), ' objects in the image!']);
end
hold off;

%% Sistema de lógica difusa
warning('off')
sistema = newfis('conteo_rayos');

%Variable de entrada: Número de objetos
sistema=addvar(sistema,'input','n_objetos',[0 200]);

%Funciones de pertenencia
sistema=addmf(sistema,'input',1,' entre_0_y_20','gaussmf', [35.4 20]);
sistema=addmf(sistema,'input',1,' entre_20_y_100','gaussmf',[35.4 100]);
sistema=addmf(sistema,'input',1,' mas_de_100','gaussmf',[35.37 200]);
plotmf(sistema,'input',1)

%Variable de entrada: Area
sistema=addvar(sistema,'input','Area', [0 5e+04]);

%Funciones de pertenencia
sistema=addmf(sistema,'input',2,'pequena','trapmf', [-1.64e+04 -6130 2800 4915]);
sistema=addmf(sistema,'input',2,'media','gaussmf', [6677 1.534e+04]);
sistema=addmf(sistema,'input',2,'grande','trapmf', [1.312e+04 2.977e+04 5.057e+04 5.067e+04]);
plotmf(sistema,'input',2)

%Variable de entrada: excentricidad
sistema=addvar(sistema,'input','excentricidad',  [0 1]);

%Funciones de pertenencia
sistema=addmf(sistema,'input',3,'no_excentrico','gaussmf', [0.289 0.261]);
sistema=addmf(sistema,'input',3,'si_excentrico','gaussmf', [0.177 0.9746]);
plotmf(sistema,'input',3)

%Variable de salida: Numero rayos
sistema=addvar(sistema,'output','numero_rayos',[0 2.5]);

%Funciones de pertenencia
sistema=addmf(sistema,'output',1,'0_rayos','gbellmf', [0.6158 3.278 0.06342]);
sistema=addmf(sistema,'output',1,'1_rayo','trimf', [0.9327 1.014 1.095]);
sistema=addmf(sistema,'output',1,'mas_de_1_rayo','gbellmf', [0.7022 3.28 2.19]);
plotmf(sistema,'output',1)

%Reglas de inferencia
ruleList=[
  	1 1 1 1 1 2 % 0 rayos
    1 1 2 1 1 2 % 0 rayos
   	1 2 2 1 1 2 % 0 rayos
    1 3 2 2 1 2 % 1 rayo
    2 1 1 1 1 2 % 0 rayos
    2 2 1 1 1 2 % 0 rayos
    2 2 2 1 1 2 % 0 rayos
    2 3 2 2 1 2 % 1 rayo
    3 1 1 1 1 2 % 0 rayos
    3 2 1 1 1 2 % 0 rayos
    3 2 2 1 1 2 % 0 rayos
    3 3 2 3 1 2]; % + de 1 rayo

sistema = addrule(sistema,ruleList);

%Sistema difuso
fuzzy(sistema)

%% Contar rayos
output_fis = zeros (numObjects, 2)
for i = 1:numObjects
    cuadro = [numObjects stats(i).Area stats(i).Eccentricity];
    Y = evalfis(cuadro, sistema)
    output_fis(i) = Y;
end
output_fis(:, 2) = floor(output_fis(:,1));
numero_rayos = sum(output_fis(:,2))